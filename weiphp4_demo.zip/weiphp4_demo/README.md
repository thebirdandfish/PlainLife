# 简介

这是梦云CMS weiapp[weiphp4.0 demo](https://coding.net/u/weiphpdev/p/weiphp4.0/git)基础上的修改版本。
如果有时间我还会进一步完善官方demo,修改版本在github: https://github.com/thebirdandfish/PlainLife

# 作者
作者: 凡星 https://coding.net/u/weiphpdev
修改: 繁琐平淡常态 https://github.com/thebirdandfish

# 修复

* 因为getUserInfo不再被支持而导致不能获取用户信息的问题.


